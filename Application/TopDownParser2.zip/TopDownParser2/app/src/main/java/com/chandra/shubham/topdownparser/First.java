package com.chandra.shubham.topdownparser;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class First extends Activity {
    TextView t;
    String g[] = new String[300];
    int n,l;
    solve s;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);
        Bundle b = this.getIntent().getExtras();
        g = b.getStringArray("grammar");
        n = b.getInt("number");
        s = new solve(g,n);
        int lrl = s.remove_left_recursion();
        int lfl = s.remove_left_factoring();
        l = s.first();
        t = (TextView) findViewById(R.id.tvFirst);
        t.setText("FIRST---------------------\n\n");

        for (int i = 0; i < l; i++)
        {
            t.append(s.first_table.get(i).get(0)+" -> { ");
            int x = s.first_table.get(i).size();
            for(int j=1;j<x-1;j++)
            {
                t.append(s.first_table.get(i).get(j)+" ,");
            }
            t.append(s.first_table.get(i).get(x-1));
            t.append(" }\n");
        }
    }
}
