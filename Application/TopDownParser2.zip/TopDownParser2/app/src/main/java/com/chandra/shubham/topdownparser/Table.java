package com.chandra.shubham.topdownparser;

import android.app.Activity;
import android.content.Intent;
import android.support.design.widget.TabLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Map;

public class Table extends Activity {

    int n;
    String g[] = new String[300];
    TextView t;
    solve s;
    Map<String ,Integer> m2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_table);
        Bundle b = this.getIntent().getExtras();
        g = b.getStringArray("grammar");
        n = b.getInt("number");
        s = new solve(g,n);
        int lrl = s.remove_left_recursion();
        int lfl = s.remove_left_factoring();
        int l1 = s.first();
        int l = s.follow();
        m2 =  s.createTable();
        t = (TextView) findViewById(R.id.tvTable);

        t.setText("");
        if(s.parse_flag==1)
        {
            t.setText("AMBIGUOUS!!");
            Toast.makeText(Table.this,"AMBIGUOUS PARSING TABLE!!",Toast.LENGTH_LONG).show();
            Intent i=new Intent(Table.this, MainActivity.class);
            Table.this.startActivity(i);
        }
        else
        {
            for(int i=0;i<=s.m1.size();i++)
            {
                for(int j=0;j<=m2.size();j++)
                {
                    String st = s.parseTable[i][j];
                    int ll = st.length();
                    for(int k=0;k<15;k++)
                        if(k<ll)
                            t.append(""+st.charAt(k));
                        else
                            t.append(" ");
                }
                t.append("\n\n");
            }



        }


    }
}
