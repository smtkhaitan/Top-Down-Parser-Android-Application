package com.chandra.shubham.topdownparser;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Grammar extends Activity {
    TextView t;
    String g[] = new String[300];
    int n,lrl,lfl;
    Button act,lr,lf;
    solve s;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grammar);
        lr = (Button)findViewById(R.id.bLR);
        lf = (Button)findViewById(R.id.bLF);
        act = (Button)findViewById(R.id.bActual);
        Bundle b = this.getIntent().getExtras();
        g = b.getStringArray("grammar");
        n = b.getInt("number");
        s = new solve(g,n);
        t = (TextView) findViewById(R.id.tvGrammar);
        t.setText("INPUT GRAMMAR:\n");
        for(int i=0;i<n;i++)
            t.append("\n"+g[i]);

        lrl = s.remove_left_recursion();
        lfl = s.remove_left_factoring();

        act.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                t.setText("INPUT GRAMMAR:\n");
                for (int i = 0; i < n; i++)
                    t.append("\n" + g[i]);
            }
        });

        lr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                t.setText("AFTER LEFT RECURSION REMOVAL:\n\n");
                for (int i = 0; i < lrl; i++)
                {
                    t.append(s.left_recursion_removed_grammer.get(i).get(0)+" -> ");

                    for(int j=1;j<s.left_recursion_removed_grammer.get(i).size();j++)
                    {
                        String ch;
                        if(j==s.left_recursion_removed_grammer.get(i).size()-1)
                            ch = "";
                        else
                            ch = " /";
                        t.append(s.left_recursion_removed_grammer.get(i).get(j) + ch);
                    }
                    t.append("\n");
                }
            }
        });

        lf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                t.setText("FINAL GRAMMAR----------------------\n\n");
                for (int i = 0; i < lfl; i++)
                {
                    t.append(s.left_factoring_removed_grammer.get(i).get(0)+" -> ");
                    for(int j=1;j<s.left_factoring_removed_grammer.get(i).size();j++)
                    {
                        String ch;
                        if(j==s.left_factoring_removed_grammer.get(i).size()-1)
                            ch = "";
                        else
                            ch = " /";
                        t.append(s.left_factoring_removed_grammer.get(i).get(j) + ch);
                    }
                    t.append("\n");
                }
            }
        });
    }
}