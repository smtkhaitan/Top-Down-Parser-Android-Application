package com.chandra.shubham.topdownparser;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Follow extends Activity {

    int n,l,l1;
    String g[] = new String[300];
    TextView t;
    solve s;
    Button first,follow;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_follow);
        first = (Button)findViewById(R.id.bFrst);
        follow = (Button)findViewById(R.id.bFllw);
        Bundle b = this.getIntent().getExtras();
        g = b.getStringArray("grammar");
        n = b.getInt("number");
        s = new solve(g,n);
        int lrl = s.remove_left_recursion();
        int lfl = s.remove_left_factoring();
        l1 = s.first();
        l = s.follow();
        t = (TextView) findViewById(R.id.tvFollow);
        t.setText("INPUT GRAMMAR:\n");
        for (int i = 0; i < n; i++)
            t.append("\n" + g[i]);


        follow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                t.setText("FOLLOW---------------------\n\n");
                for (int i = 0; i < l; i++) {
                    t.append(s.follow_table.get(i).get(0) + " -> { ");
                    int x = s.follow_table.get(i).size();
                    for (int j = 1; j < x - 1; j++) {
                        t.append(s.follow_table.get(i).get(j) + " ,");
                    }
                    t.append(s.follow_table.get(i).get(x - 1));
                    t.append(" }\n");
                }
            }
        });

        first.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                t.setText("FIRST---------------------\n\n");

                for (int i = 0; i < l1; i++)
                {
                    t.append(s.first_table.get(i).get(0)+" -> { ");
                    int x = s.first_table.get(i).size();
                    for(int j=1;j<x-1;j++)
                    {
                        t.append(s.first_table.get(i).get(j)+" ,");
                    }
                    t.append(s.first_table.get(i).get(x-1));
                    t.append(" }\n");
                }
            }
        });
    }
}
