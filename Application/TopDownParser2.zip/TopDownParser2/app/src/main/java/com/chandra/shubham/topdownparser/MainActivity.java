package com.chandra.shubham.topdownparser;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {

    int n;
    boolean ac = true;
    Button submit,next,first,follow,tab,gmm;
    EditText e;
    String g[] = new String[300];
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        n = 0;
        submit = (Button)findViewById(R.id.bSub);
        next = (Button)findViewById(R.id.bNext);
        first = (Button)findViewById(R.id.bFirst);
        follow = (Button)findViewById(R.id.bFollow);
        tab = (Button)findViewById(R.id.bTable);
        gmm = (Button)findViewById(R.id.bGrammar);
        e = (EditText)findViewById(R.id.editText);

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                if(!ac)
                {
                    e.setText("");
                    Toast.makeText(MainActivity.this,"No more submissions!!",Toast.LENGTH_LONG).show();
                    return;
                }
                String s = e.getText().toString().trim();
                System.out.println(s);
                g[n] = s;
                System.out.println(g[n++]);
                e.setText("");
            }
        });

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                ac = false;
            }
        });

        first.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                ac = true;
                n = 0;
                Toast.makeText(MainActivity.this,"Refreshed",Toast.LENGTH_SHORT).show();
            }
        });

        follow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                Bundle b=new Bundle();
                b.putStringArray("grammar", g);
                b.putInt("number", n);
                Intent i=new Intent(MainActivity.this, Follow.class);
                i.putExtras(b);
                MainActivity.this.startActivity(i);
            }
        });

        tab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                Bundle b = new Bundle();
                b.putStringArray("grammar", g);
                b.putInt("number", n);
                Intent i = new Intent(MainActivity.this, Table.class);
                i.putExtras(b);
                MainActivity.this.startActivity(i);
            }
        });

        gmm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                Bundle b = new Bundle();
                b.putStringArray("grammar", g);
                b.putInt("number", n);
                Intent i = new Intent(MainActivity.this, Grammar.class);
                i.putExtras(b);
                MainActivity.this.startActivity(i);
            }
        });


    }
}
